请在皮肤站的 `.env` 配置文件中添加并填写以下条目：

```
OSS_ACCESS_ID=
OSS_ACCESS_KEY=
OSS_BUCKET=
# 外网节点或自定义外部域名
OSS_ENDPOINT=oss-cn-hangzhou.aliyuncs.com
OSS_SSL=true

# 本插件对 OSS 自定义 CDN 域名支持仍不完善，不建议开启
# OSS_CDN_DOMAIN=cdn.example.com
# 是否使用自定义域名
# OSS_IS_CNAME=false
```
